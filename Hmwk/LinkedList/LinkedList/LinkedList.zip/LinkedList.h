/*
* Jose Sandoval
* CIS-17C: C++ Programming
* September 24, 2014
* Homework #4: Linked List
* Description: Linked list data structure
*/

#ifndef LINKEDLIST_H
#define	LINKEDLIST_H

// Libraries
#include <string>
#include <iostream>
using namespace std;

class LinkedList 
{
public:
	LinkedList(int);
	void append(int);
	string toString();
	virtual ~LinkedList();
private:
	struct Node
	{
		int data;
		Node *next;
	};
	Node *head;
	Node *worker;
};

#endif	/* LNKDLST_H */


