/*
* Jose Sandoval
* CIS-17C: C++ Programming
* September 24, 2014
* Homework #4: Linked List
* Description: Linked list data structure
*/

// Libraries
#include "LinkedList.h"

int main(int argc, char** argv) 
{
	//Create a linked list
	LinkedList list(0);

	//Append 3 more chains
	int clinks = 3;
	for (int i = 1; i <= clinks; i++)
	{
		list.append(i);
	}

	//Print the data
	cout << list.toString() << endl;

	//Exit stage right!
	return 0;
}