#include "LinkedList.h"

LinkedList::LinkedList(int data)
{
	Node *clink = new Node;
	clink->data = data;
	clink->next = NULL;
	head = clink;
}

LinkedList::~LinkedList()
{
	if(head)
	{
		do
		{
			worker = head;
			head = head->next;
			delete worker;
		} while (head);
	}
}

void LinkedList::append(int data)
{
	Node *prev;
	if (head)
	{
		worker = head;
		do
		{
			prev = worker;
		} while (worker = worker->next);
	}

	Node *clink = new Node;
	clink->data = data;
	clink->next = head;
	head = clink;
}

string LinkedList::toString()
{
	string output;
	if (head)
	{
		worker = head;
		do
		{
			output += "Data element in the list: ";
			output += to_string(worker->data) + "\n";
		} while (worker = worker->next);
	}

	return output;
}