namespace GameState
{
	enum GameState
	{
		GAMEOVER,
		PLAYING
	};
}